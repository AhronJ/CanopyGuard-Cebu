﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Security.Cryptography;
using System.Text;

namespace CanopyGuard
{
    public class User
    {
        public string Username { get; set; }
        public string PasswordHash { get; set; }
        public string Role { get; set; } // "admin" or "user"
        public DateTime CreatedDate { get; set; }
        public DateTime LastLogin { get; set; }

        public User()
        {
            CreatedDate = DateTime.Now;
            LastLogin = DateTime.Now;
            Role = "user";
        }
    }

    public class Tree
    {
        public int Id { get; set; }
        public string Species { get; set; }
        public string Location { get; set; }
        public DateTime PlantingDate { get; set; }
        public string HealthStatus { get; set; }
        public DateTime LastPrunedDate { get; set; }
        public DateTime LastInspectedDate { get; set; }
        public string Notes { get; set; }
        public bool IsRemoved { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; }

        public Tree()
        {
            PlantingDate = DateTime.Now;
            LastPrunedDate = DateTime.Now.AddYears(-1);
            LastInspectedDate = DateTime.Now;
            HealthStatus = "Good";
            IsRemoved = false;
            CreatedDate = DateTime.Now;
        }
    }

    public class ActivityLog
    {
        public string Username { get; set; }
        public string Action { get; set; }
        public DateTime Timestamp { get; set; }
        public string Details { get; set; }
    }

    class Program
    {
        private static List<Tree> trees = new List<Tree>();
        private static List<User> users = new List<User>();
        private static List<ActivityLog> activityLogs = new List<ActivityLog>();
        private static User currentUser = null;
        private static int nextTreeId = 1;
        private const string TreeDataFile = "trees.json";
        private const string UserDataFile = "users.json";
        private const string LogDataFile = "activity_logs.json";

        static void Main(string[] args)
        {
            LoadAllData();

            if (ShowLoginScreen())
            {
                LogActivity("login", "User logged in");
                ShowWelcomeScreen();
                MainMenuLoop();
            }

            SaveAllData();
            ShowGoodbyeMessage();
        }

        // ========== AUTHENTICATION & USER MANAGEMENT ==========
        private static bool ShowLoginScreen()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n");
            Console.WriteLine("________________________________________________");
            Console.WriteLine("           CANOPYGUARD - LOGIN");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;

            int attempts = 0;
            const int maxAttempts = 3;

            while (attempts < maxAttempts)
            {
                Console.Write("\nUsername: ");
                string username = Console.ReadLine();

                Console.Write("Password: ");
                string password = ReadPassword();

                if (AuthenticateUser(username, password))
                {
                    currentUser.LastLogin = DateTime.Now;
                    SaveAllData();
                    return true;
                }

                attempts++;
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\nInvalid credentials. Attempts remaining: {maxAttempts - attempts}");
                Console.ForegroundColor = ConsoleColor.White;

                if (attempts < maxAttempts)
                {
                    Console.Write("\nTry again? (y/n): ");
                    if (Console.ReadLine().ToLower() != "y")
                        break;
                }
            }

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\nMaximum login attempts exceeded. Exiting...");
            Console.ForegroundColor = ConsoleColor.White;
            Console.ReadKey();
            return false;
        }

        private static string ReadPassword()
        {
            StringBuilder password = new StringBuilder();
            ConsoleKeyInfo key;

            do
            {
                key = Console.ReadKey(true);
                if (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter)
                {
                    password.Append(key.KeyChar);
                    Console.Write("*");
                }
                else if (key.Key == ConsoleKey.Backspace && password.Length > 0)
                {
                    password.Remove(password.Length - 1, 1);
                    Console.Write("\b \b");
                }
            }
            while (key.Key != ConsoleKey.Enter);

            Console.WriteLine();
            return password.ToString();
        }

        private static bool AuthenticateUser(string username, string password)
        {
            var user = users.FirstOrDefault(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
            if (user != null)
            {
                if (VerifyPassword(password, user.PasswordHash))
                {
                    currentUser = user;
                    return true;
                }
            }
            return false;
        }

        private static string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var bytes = Encoding.UTF8.GetBytes(password);
                var hash = sha256.ComputeHash(bytes);
                return Convert.ToBase64String(hash);
            }
        }

        private static bool VerifyPassword(string password, string storedHash)
        {
            return HashPassword(password) == storedHash;
        }

        private static void CreateAdminIfNotExists()
        {
            if (!users.Any(u => u.Username.Equals("admin", StringComparison.OrdinalIgnoreCase)))
            {
                var admin = new User
                {
                    Username = "admin",
                    PasswordHash = HashPassword("admin123"),
                    Role = "admin"
                };
                users.Add(admin);
                SaveUserData();
                Console.WriteLine("Default admin account created: username=admin, password=admin123");
            }
        }

        private static void UserManagementMenu()
        {
            if (currentUser.Role != "admin")
            {
                ShowMessage("Access denied. Admin rights required.", "error");
                return;
            }

            bool exit = false;
            while (!exit)
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Magenta;
                Console.WriteLine("\n");
                Console.WriteLine("________________________________________________");
                Console.WriteLine("              USER MANAGEMENT");
                Console.WriteLine("________________________________________________");
                Console.ForegroundColor = ConsoleColor.White;

                Console.WriteLine("1. Create New User");
                Console.WriteLine("2. View All Users");
                Console.WriteLine("3. Change User Password");
                Console.WriteLine("4. View Activity Logs");
                Console.WriteLine("5. Back to Main Menu");
                Console.Write("\nSelect an option: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1": CreateNewUser(); break;
                    case "2": ViewAllUsers(); break;
                    case "3": ChangeUserPassword(); break;
                    case "4": ViewActivityLogs(); break;
                    case "5": exit = true; break;
                    default: ShowMessage("Invalid choice.", "error"); break;
                }

                if (!exit)
                {
                    Console.WriteLine("\nPress any key to continue...");
                    Console.ReadKey();
                }
            }
        }

        private static void CreateNewUser()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n");
            Console.WriteLine("________________________________________________");
            Console.WriteLine("              CREATE NEW USER");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;

            Console.Write("Enter username: ");
            string username = Console.ReadLine();

            if (users.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase)))
            {
                ShowMessage("Username already exists.", "error");
                return;
            }

            Console.Write("Enter password: ");
            string password = ReadPassword();

            Console.Write("Confirm password: ");
            string confirmPassword = ReadPassword();

            if (password != confirmPassword)
            {
                ShowMessage("Passwords do not match.", "error");
                return;
            }

            Console.Write("Enter role (admin/user) [user]: ");
            string role = Console.ReadLine().ToLower();
            if (string.IsNullOrEmpty(role) || (role != "admin" && role != "user"))
                role = "user";

            var newUser = new User
            {
                Username = username,
                PasswordHash = HashPassword(password),
                Role = role
            };

            users.Add(newUser);
            SaveUserData();
            LogActivity("user_creation", $"Created user: {username} ({role})");
            ShowMessage($"User '{username}' created successfully.", "success");
        }

        private static void ChangeUserPassword()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n");
            Console.WriteLine("________________________________________________");
            Console.WriteLine("              CHANGE PASSWORD");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;

            Console.Write("Enter username: ");
            string username = Console.ReadLine();

            var user = users.FirstOrDefault(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
            if (user == null)
            {
                ShowMessage("User not found.", "error");
                return;
            }

            Console.Write("Enter new password: ");
            string newPassword = ReadPassword();

            Console.Write("Confirm new password: ");
            string confirmPassword = ReadPassword();

            if (newPassword != confirmPassword)
            {
                ShowMessage("Passwords do not match.", "error");
                return;
            }

            user.PasswordHash = HashPassword(newPassword);
            SaveUserData();
            LogActivity("password_change", $"Password changed for user: {username}");
            ShowMessage("Password changed successfully.", "success");
        }

        private static void ViewAllUsers()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\n");
            Console.WriteLine("USER LIST");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();

            PrintTableHeader("Username", "Role", "Created", "Last Login");

            foreach (var user in users.OrderBy(u => u.Username))
            {
                PrintTableRow(
                    user.Username,
                    user.Role,
                    user.CreatedDate.ToString("MM/dd/yyyy"),
                    user.LastLogin.ToString("MM/dd/yyyy HH:mm")
                );
            }

            PrintTableFooter();
        }

        private static void ViewActivityLogs()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n");
            Console.WriteLine("ACTIVITY LOGS");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();

            var recentLogs = activityLogs.OrderByDescending(l => l.Timestamp).Take(50).ToList();

            if (recentLogs.Count == 0)
            {
                ShowMessage("No activity logs found.", "info");
                return;
            }

            PrintTableHeader("Timestamp", "User", "Action", "Details");

            foreach (var log in recentLogs)
            {
                PrintTableRow(
                    log.Timestamp.ToString("MM/dd/yyyy HH:mm"),
                    log.Username,
                    log.Action,
                    log.Details.Length > 20 ? log.Details.Substring(0, 20) + "..." : log.Details
                );
            }

            PrintTableFooter();
        }

        // ========== UPDATED TREE METHODS WITH USER TRACKING ==========
        private static void AddTree()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n");
            Console.WriteLine("________________________________________________");
            Console.WriteLine("                  ADD NEW TREE");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;

            Tree tree = new Tree();
            tree.Id = GetNextAvailableId();
            tree.CreatedBy = currentUser.Username;

            Console.Write("Enter species: ");
            tree.Species = Console.ReadLine();

            Console.Write("Enter location: ");
            tree.Location = Console.ReadLine();

            Console.Write("Enter planting date (yyyy-mm-dd) [today]: ");
            string dateInput = Console.ReadLine();
            if (!string.IsNullOrEmpty(dateInput) && DateTime.TryParse(dateInput, out DateTime plantDate))
            {
                tree.PlantingDate = plantDate;
            }

            Console.Write("Enter health status (Excellent/Good/Fair/Poor) [Good]: ");
            string health = Console.ReadLine();
            if (!string.IsNullOrEmpty(health))
            {
                tree.HealthStatus = health;
            }

            trees.Add(tree);
            LogActivity("add_tree", $"Added tree ID {tree.Id}: {tree.Species} at {tree.Location}");
            ShowMessage($"Tree added successfully with ID: {tree.Id}", "success");
        }

        static void ViewAllTrees()
        {
            Console.Clear();
            var activeTrees = trees.Where(t => !t.IsRemoved).OrderBy(t => t.Id).ToList();

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("\n");
            Console.WriteLine("COMPLETE TREE INVENTORY");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();

            if (activeTrees.Count == 0)
            {
                ShowMessage("No trees in inventory.", "info");
                return;
            }

            PrintTableHeader("Tree ID", "Species", "Location", "Health", "Date Planted");

            foreach (var tree in activeTrees)
            {
                PrintTableRow(
                    tree.Id.ToString(),
                    tree.Species,
                    tree.Location,
                    tree.HealthStatus,
                    tree.PlantingDate.ToString("MM/dd/yyyy")
                );
            }

            PrintTableFooter();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\nTotal active trees: {activeTrees.Count}");
            Console.ForegroundColor = ConsoleColor.White;
        }

        static void SearchTrees()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\n");
            Console.WriteLine("________________________________________________");
            Console.WriteLine("                  SEARCH TREES");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("1. Search by Species");
            Console.WriteLine("2. Search by Location");
            Console.Write("Select search type: ");

            string choice = Console.ReadLine();
            Console.Write("Enter search term: ");
            string searchTerm = Console.ReadLine().ToLower();

            var results = trees.Where(t => !t.IsRemoved).ToList();

            if (choice == "1")
            {
                results = results.Where(t => t.Species.ToLower().Contains(searchTerm)).ToList();
            }
            else if (choice == "2")
            {
                results = results.Where(t => t.Location.ToLower().Contains(searchTerm)).ToList();
            }

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine($"\nSEARCH RESULTS ({results.Count} trees found)");
            Console.ForegroundColor = ConsoleColor.White;

            if (results.Count == 0)
            {
                ShowMessage("No trees found matching your search", "info");
                return;
            }

            PrintTableHeader("Tree ID", "Species", "Location", "Health");

            foreach (var tree in results.OrderBy(t => t.Id))
            {
                PrintTableRow(
                    tree.Id.ToString(),
                    tree.Species,
                    tree.Location,
                    tree.HealthStatus
                );
            }
            PrintTableFooter();
        }

        private static void RecordInspection()
        {
            Console.Clear();
            ViewAllTrees();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n");
            Console.WriteLine("________________________________________________");
            Console.WriteLine("              RECORD TREE INSPECTION");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;

            Console.Write("Enter tree ID to inspect: ");

            if (int.TryParse(Console.ReadLine(), out int treeId))
            {
                var tree = trees.FirstOrDefault(t => t.Id == treeId && !t.IsRemoved);
                if (tree != null)
                {
                    Console.WriteLine($"\nInspecting: {tree.Species} at {tree.Location}");
                    Console.Write("Enter health status (Excellent/Good/Fair/Poor): ");
                    tree.HealthStatus = Console.ReadLine();

                    Console.Write("Enter inspection notes: ");
                    tree.Notes = Console.ReadLine();

                    tree.LastInspectedDate = DateTime.Now;

                    LogActivity("inspection", $"Inspected tree ID {tree.Id}, new health: {tree.HealthStatus}");
                    ShowMessage($"Inspection recorded for Tree ID {tree.Id}", "success");
                }
                else
                {
                    ShowMessage("Tree not found or has been removed.", "error");
                }
            }
            else
            {
                ShowMessage("Invalid ID format.", "error");
            }
        }

        static void ViewMaintenanceQueue()
        {
            Console.Clear();
            var needsMaintenance = trees.Where(t => !t.IsRemoved && (
                t.HealthStatus == "Poor" ||
                DateTime.Now.Subtract(t.LastPrunedDate).TotalDays > 730
            )).OrderBy(t => t.Id).ToList();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n");
            Console.WriteLine("MAINTENANCE QUEUE - TREES NEEDING ATTENTION");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();

            if (needsMaintenance.Count == 0)
            {
                ShowMessage("No trees currently need maintenance. All trees are healthy and up-to-date!", "success");
                return;
            }

            PrintTableHeader("Tree ID", "Species", "Location", "Issue", "Days Since Prune");

            foreach (var tree in needsMaintenance)
            {
                string reason = tree.HealthStatus == "Poor" ? "Poor Health" : "Needs Pruning";
                int daysSincePruning = (int)DateTime.Now.Subtract(tree.LastPrunedDate).TotalDays;

                PrintTableRow(
                    tree.Id.ToString(),
                    tree.Species,
                    tree.Location,
                    reason,
                    daysSincePruning.ToString()
                );
            }
            PrintTableFooter();
            ShowMessage($"{needsMaintenance.Count} trees require immediate attention", "warning");
        }

        static void GenerateBiodiversityReport()
        {
            Console.Clear();
            var activeTrees = trees.Where(t => !t.IsRemoved).ToList();

            if (activeTrees.Count == 0)
            {
                ShowMessage("No trees in inventory to generate report.", "error");
                return;
            }

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n");
            Console.WriteLine("BIODIVERSITY REPORT");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();

            // Species Distribution
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("SPECIES DISTRIBUTION");
            Console.ForegroundColor = ConsoleColor.White;

            var speciesGroups = activeTrees.GroupBy(t => t.Species)
                                          .Select(g => new { Species = g.Key, Count = g.Count() })
                                          .OrderByDescending(x => x.Count);

            PrintTableHeader("Species", "Count", "Percentage");

            foreach (var group in speciesGroups)
            {
                double percentage = (double)group.Count / activeTrees.Count * 100;
                PrintTableRow(group.Species, group.Count.ToString(), $"{percentage:F1}%");
            }
            PrintTableFooter();

            // Health Distribution
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\nHEALTH DISTRIBUTION");
            Console.ForegroundColor = ConsoleColor.White;

            var healthGroups = activeTrees.GroupBy(t => t.HealthStatus)
                                         .Select(g => new { Health = g.Key, Count = g.Count() })
                                         .OrderByDescending(x => x.Count);

            PrintTableHeader("Health Status", "Count", "Percentage");

            foreach (var group in healthGroups)
            {
                double percentage = (double)group.Count / activeTrees.Count * 100;
                PrintTableRow(group.Health, group.Count.ToString(), $"{percentage:F1}%");
            }
            PrintTableFooter();

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\nTotal trees in inventory: {activeTrees.Count}");
            Console.ForegroundColor = ConsoleColor.White;
        }

        private static void RemoveTree()
        {
            Console.Clear();
            ViewAllTrees();

            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n");
            Console.WriteLine("________________________________________________");
            Console.WriteLine("             REMOVE TREE FROM INVENTORY");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;

            Console.Write("Enter tree ID to remove: ");

            if (int.TryParse(Console.ReadLine(), out int treeId))
            {
                var tree = trees.FirstOrDefault(t => t.Id == treeId && !t.IsRemoved);
                if (tree != null)
                {
                    Console.WriteLine($"\nTree to remove: {tree.Species} at {tree.Location}");
                    Console.Write("Enter reason for removal: ");
                    string reason = Console.ReadLine();

                    Console.Write("Are you sure? (y/n): ");
                    string confirm = Console.ReadLine().ToLower();

                    if (confirm == "y" || confirm == "yes")
                    {
                        tree.IsRemoved = true;
                        LogActivity("remove_tree", $"Removed tree ID {tree.Id}. Reason: {reason}");
                        ShowMessage($"Tree ID {tree.Id} has been removed from active inventory.", "success");
                    }
                    else
                    {
                        ShowMessage("Removal cancelled.", "info");
                    }
                }
                else
                {
                    ShowMessage("Tree not found or already removed.", "error");
                }
            }
            else
            {
                ShowMessage("Invalid ID format.", "error");
            }
        }

        // ========== ENHANCED MAIN MENU ==========
        private static void DisplayMainMenu()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n");
            Console.WriteLine("________________________________________________");
            Console.WriteLine($"          MAIN MENU - Welcome, {currentUser.Username}!");
            Console.WriteLine($"          Role: {currentUser.Role.ToUpper()}");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("1. Add New Tree");
            Console.WriteLine("2. View All Trees");
            Console.WriteLine("3. Search Trees");
            Console.WriteLine("4. Record Inspection");
            Console.WriteLine("5. Maintenance Queue");
            Console.WriteLine("6. Biodiversity Report");
            Console.WriteLine("7. Remove Tree");

            if (currentUser.Role == "admin")
            {
                Console.WriteLine("8. User Management");
                Console.WriteLine("9. Logout");
                Console.WriteLine("0. Exit");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("________________________________________________");
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\nSelect an option (0-9): ");
            }
            else
            {
                Console.WriteLine("8. Logout");
                Console.WriteLine("9. Exit");
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("________________________________________________");
                Console.ForegroundColor = ConsoleColor.White;
                Console.Write("\nSelect an option (1-9): ");
            }
        }

        private static void MainMenuLoop()
        {
            bool exit = false;
            while (!exit)
            {
                DisplayMainMenu();
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1": AddTree(); break;
                    case "2": ViewAllTrees(); break;
                    case "3": SearchTrees(); break;
                    case "4": RecordInspection(); break;
                    case "5": ViewMaintenanceQueue(); break;
                    case "6": GenerateBiodiversityReport(); break;
                    case "7": RemoveTree(); break;
                    case "8":
                        if (currentUser.Role == "admin")
                            UserManagementMenu();
                        else
                            Logout(ref exit);
                        break;
                    case "9":
                        if (currentUser.Role == "admin")
                            Logout(ref exit);
                        else
                            exit = true;
                        break;
                    case "0":
                        if (currentUser.Role == "admin")
                            exit = true;
                        else
                            ShowMessage("Invalid choice.", "error");
                        break;
                    default:
                        ShowMessage("Invalid choice.", "error");
                        break;
                }

                if (!exit && choice != "8") // Don't pause if user selected user management
                {
                    Console.WriteLine("\nPress any key to continue...");
                    Console.ReadKey();
                }
            }
        }

        private static void Logout(ref bool exit)
        {
            LogActivity("logout", "User logged out");
            ShowMessage("Logged out successfully.", "success");
            Console.WriteLine("\nPress any key to return to login...");
            Console.ReadKey();

            if (ShowLoginScreen())
            {
                LogActivity("login", "User logged in");
                ShowWelcomeScreen();
            }
            else
            {
                exit = true;
            }
        }

        // ========== LOGGING UTILITY ==========
        private static void LogActivity(string action, string details)
        {
            var log = new ActivityLog
            {
                Username = currentUser.Username,
                Action = action,
                Timestamp = DateTime.Now,
                Details = details
            };
            activityLogs.Add(log);

            // Keep only last 1000 logs to prevent file bloat
            if (activityLogs.Count > 1000)
                activityLogs = activityLogs.Skip(activityLogs.Count - 1000).ToList();
        }

        // ========== DATA PERSISTENCE ==========
        private static void SaveAllData()
        {
            SaveTreeData();
            SaveUserData();
            SaveLogData();
        }

        private static void LoadAllData()
        {
            LoadTreeData();
            LoadUserData();
            LoadLogData();
            CreateAdminIfNotExists();
        }

        private static void SaveTreeData()
        {
            try
            {
                var data = new { Trees = trees, NextTreeId = nextTreeId };
                string json = JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(TreeDataFile, json);
            }
            catch (Exception ex)
            {
                ShowMessage($"Error saving tree data: {ex.Message}", "error");
            }
        }

        private static void LoadTreeData()
        {
            try
            {
                if (File.Exists(TreeDataFile))
                {
                    string json = File.ReadAllText(TreeDataFile);
                    var data = JsonSerializer.Deserialize<JsonElement>(json);

                    if (data.TryGetProperty("Trees", out JsonElement treesElement))
                    {
                        trees = JsonSerializer.Deserialize<List<Tree>>(treesElement.GetRawText());
                    }

                    if (data.TryGetProperty("NextTreeId", out JsonElement nextIdElement))
                    {
                        nextTreeId = nextIdElement.GetInt32();
                    }
                }
            }
            catch (Exception ex)
            {
                ShowMessage($"Error loading tree data: {ex.Message}", "error");
            }
        }

        private static void SaveUserData()
        {
            try
            {
                string json = JsonSerializer.Serialize(users, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(UserDataFile, json);
            }
            catch (Exception ex)
            {
                ShowMessage($"Error saving user data: {ex.Message}", "error");
            }
        }

        private static void LoadUserData()
        {
            try
            {
                if (File.Exists(UserDataFile))
                {
                    string json = File.ReadAllText(UserDataFile);
                    users = JsonSerializer.Deserialize<List<User>>(json);
                }
            }
            catch (Exception ex)
            {
                ShowMessage($"Error loading user data: {ex.Message}", "error");
            }
        }

        private static void SaveLogData()
        {
            try
            {
                string json = JsonSerializer.Serialize(activityLogs, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(LogDataFile, json);
            }
            catch (Exception ex)
            {
                ShowMessage($"Error saving log data: {ex.Message}", "error");
            }
        }

        private static void LoadLogData()
        {
            try
            {
                if (File.Exists(LogDataFile))
                {
                    string json = File.ReadAllText(LogDataFile);
                    activityLogs = JsonSerializer.Deserialize<List<ActivityLog>>(json);
                }
            }
            catch (Exception ex)
            {
                ShowMessage($"Error loading log data: {ex.Message}", "error");
            }
        }

        // ========== HELPER METHODS ==========
        private static int GetNextAvailableId()
        {
            var activeTrees = trees.Where(t => !t.IsRemoved).ToList();
            if (activeTrees.Count == 0) return 1;

            var activeIds = activeTrees.Select(t => t.Id).OrderBy(id => id).ToList();

            for (int i = 1; i <= activeIds.Max(); i++)
            {
                if (!activeIds.Contains(i))
                {
                    return i;
                }
            }

            return activeIds.Max() + 1;
        }

        static void PrintTableHeader(params string[] headers)
        {
            Console.ForegroundColor = ConsoleColor.White;
            string line = new string('_', 80);
            Console.WriteLine(line);

            string headerRow = "|";
            foreach (string header in headers)
            {
                headerRow += $" {header,-12} |";
            }
            Console.WriteLine(headerRow);
            Console.WriteLine(line);
        }

        static void PrintTableRow(params string[] columns)
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            string row = "|";
            foreach (string column in columns)
            {
                string displayText = column.Length > 12 ? column.Substring(0, 10) + ".." : column;
                row += $" {displayText,-12} |";
            }
            Console.WriteLine(row);
        }

        static void PrintTableFooter()
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(new string('_', 80));
        }

        static void ShowMessage(string message, string type = "info")
        {
            Console.WriteLine();
            switch (type.ToLower())
            {
                case "success":
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine($"[SUCCESS] {message}");
                    break;
                case "error":
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine($"[ERROR] {message}");
                    break;
                case "warning":
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"[WARNING] {message}");
                    break;
                default:
                    Console.ForegroundColor = ConsoleColor.Cyan;
                    Console.WriteLine($"[INFO] {message}");
                    break;
            }
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine();
        }

        static void ShowWelcomeScreen()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n");
            Console.WriteLine("________________________________________________");
            Console.WriteLine($"    WELCOME TO CANOPYGUARD, {currentUser.Username.ToUpper()}!");
            Console.WriteLine("      Urban Tree Management System");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"Loaded {trees.Count(t => !t.IsRemoved)} active trees");
            Console.WriteLine($"Total users: {users.Count}");
            Console.WriteLine($"Last login: {currentUser.LastLogin:MM/dd/yyyy HH:mm}");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n");
        }

        static void ShowGoodbyeMessage()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("\n");
            Console.WriteLine("________________________________________________");
            Console.WriteLine($"    THANK YOU FOR USING CANOPYGUARD, {currentUser?.Username?.ToUpper() ?? "User"}!");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"Data saved: {trees.Count(t => !t.IsRemoved)} active trees");
            Console.WriteLine($"Total users: {users.Count}");
            Console.WriteLine($"Activity logs: {activityLogs.Count}");
            Console.WriteLine($"File location: {Path.GetFullPath(".")}");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("________________________________________________");
            Console.WriteLine("      Keep our urban forest healthy!");
            Console.WriteLine("________________________________________________");
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("\n");
        }
    }
}